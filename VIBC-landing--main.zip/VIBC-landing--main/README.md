# VIBC-landing-
Official VIBC meme coin landing page 
